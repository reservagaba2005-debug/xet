# AimTrainer - Windows x64 (Release)

Aim trainer independente. Não lê memória nem interage com CS2 ou outros jogos.

## Compilar no GitHub Actions pelo celular
1. Crie um repositório no GitHub.
2. Envie **o conteúdo desta pasta** (não apenas o ZIP) para a raiz do repositório.
3. Abra a aba **Actions** e execute `Build AimTrainer Windows x64`.
4. Ao terminar com sucesso, baixe o artefato `AimTrainer-Windows-x64-Release`.
5. Extraia o ZIP do artefato e execute `AimTrainer.exe` no Windows.

## Compilar localmente (Visual Studio 2022)
```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
```
O CMake seleciona o runtime estático `/MT` em Release, evitando a dependência das DLLs de depuração
`VCRUNTIME140D.dll` e `ucrtbased.dll`.

## Controles
- Clique no alvo: registra tentativa/acerto.
- R: reinicia as estatísticas.
- + / -: aumenta/diminui o tamanho do alvo.
- Esc: fecha.

Este pacote contém código-fonte e workflow; o executável deve ser gerado no runner Windows do GitHub Actions.
